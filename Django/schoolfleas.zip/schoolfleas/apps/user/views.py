# 导入View抽象类post,get方法
from django.views.generic import View

# 导入django自带的认证方法
from django.contrib.auth import authenticate
from django.http import JsonResponse

# 导入数据库模型
from apps.user.models import User  # 这李绝对路径会报错，我也不知道为啥，百度的

from celery_tasks.tasks import send_register_active_email
# 导入setting中的密文SECRET_KEY
from django.conf import settings

# 导入加密 需要 pip install itsdangerous
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
# 解密时间过期异常类
from itsdangerous import SignatureExpired
# 导入setting中的密文SECRET_KEY
from django.conf import settings


# Create your views here.
class RegisterView(View):
    def get(self, request):
        pass

    def post(self, request):
        # username = request.POST.get('account')
        username = ''
        password = request.POST.get('password')
        email = request.POST.get('account')
        code = request.POST.get('code')

        # 判断验证码是否正确
        if request.session['checkcode'] == code:
            # 3.业务逻辑处理
            user = User.objects.create_user(username, email, password)
            # 将用户设置为未激活状态
            user.is_active = 1
            user.save()
        else:
            return JsonResponse({'isSuccess': 'false', 'msg': "验证码错误！"})
        # 生成user_token
        # 3600s为过期时间
        # setting.SECRET_KEY为密文
        serializer = Serializer(settings.SECRET_KEY, 3600)
        return JsonResponse({'isSuccess': 'true', 'msg': "注册成功！"})


class SendMailView(View):
    def get(self, request):
        pass

    def post(self, request):
        # 获取传过来的email
        email = request.POST.get('email')

        # 判断该邮箱是否已经被注册
        try:
            recheck = User.objects.get(email=email)
        except User.DoesNotExist:
            recheck = None

        # 假如邮箱已经存在
        if recheck:
            return JsonResponse({'isSuccess': 'false', 'msg': "该邮箱已被注册！"})

        # 异步发送邮件
        checkcode = send_register_active_email.delay(email)
        # 保存session
        request.session['checkcode'] = checkcode
        return JsonResponse({'isSuccess': 'true', 'msg': '发送成功！'})


class LoginView(View):
    def get(self, request):
        pass

    def post(self, request):
        email = request.POST.get('account')
        password = request.POST.get('password')

        user = authenticate(email=email, password=password)

        if user:
            # 加密文件
            info = {'id': user.id, 'update_time': user.update_time}
            # 加密
            # 生成token
            # 3600s为过期时间
            # setting.SECRET_KEY为密文
            serializer = Serializer(settings.SECRET_KEY)
            # 加密是dumps 解密为loads
            # 二进制形式
            token = serializer.dumps(info)  # bytes
            # 转化为utf-8形式
            token = token.decode()
            #         保存token
            user.user_token = token
            user.save()
            return JsonResponse({'uid': user.id, 'isSuccess': 'true', 'token': token})
        else:
            return JsonResponse({'isSuccess': 'false', 'msg': '账号或密码错误'})
