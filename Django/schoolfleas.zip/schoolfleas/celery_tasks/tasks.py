# 使用celery
import time
import os
import random
from random import shuffle

import django
from celery import Celery

# 导入发送邮件的类
from django.core.mail import send_mail
from django.conf import settings

# 创建一个Celery类的实例对象
from django.http import request

app = Celery('celery_tasks.tasks', broker='redis://127.0.0.1:6379/1')

# 初始化django 因为下面需要使用django本身的配置项settings.EMAIL_FROM
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'schoolfleas.settings')
django.setup()


# 定义任务函数
@app.task
def send_register_active_email(to_email):
    # 发送邮件
    subject = '【校园跳蚤】账户激活提醒'
    # 这个不能发html格式的邮件
    message = ''
    sender = settings.EMAIL_FROM  # 发件人
    reciver = [to_email]

    # 生成验证码
    checkcodes = shuffle_str()[0:6]  # 截取0-6位
    html_message = "<h1>尊敬的%s用户您好，欢迎注册校园跳蚤应用</h1>您的验证码为：%s" % (reciver, checkcodes)
    send_mail(subject, message, sender, reciver, html_message=html_message)
    # time.sleep()
    return checkcodes


# 验证码1  字母+数字
def shuffle_str():
    # 验证码字库
    checkstrs = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    # 将字符串转换成列表
    str_list = list(checkstrs)
    # 调用random模块的shuffle函数打乱列表
    shuffle(str_list)
    # 将列表转字符串
    return ''.join(str_list)

# 验证码2 纯数字
# def shuffle_str2():
#     strcode = ''
#     for i in range(6):
#         strcode = strcode.join(str(random.randint(0, 9)))
#     return strcode
